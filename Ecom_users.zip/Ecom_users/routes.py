# routes.py
from flask import Blueprint, jsonify, request
from werkzeug.security import generate_password_hash
from flask_jwt import jwt_required
from user_service import db
from user_service.models import User

user_bp = Blueprint('user_bp', __name__)

@user_bp.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    username = data.get('username')
    password = generate_password_hash(data.get('password'))
    role = data.get('role')
    new_user = User(username=username, password=password, role=role)
    db.session.add(new_user)
    db.session.commit()
    return jsonify({'message': 'User created successfully'})

@user_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username')
    password = data.get('password')
    user = User.query.filter_by(username=username).first()
    if user and user.password == password:
        # Generate JWT token
        token = jwt.encode_callback(jwt.identity(user), jwt.jwt.jwt)
        return jsonify({'token': token})
    else:
        return jsonify({'message': 'Invalid username or password'}), 401

@user_bp.route('/profile', methods=['GET'])
@jwt_required()
def profile():
    current_user = current_identity
    return jsonify({'username': current_user.username, 'role': current_user.role})
