# services.py
from user_service.models import User
from user_service import db

def get_user_by_username(username):
    return User.query.filter_by(username=username).first()

def get_user_by_id(user_id):
    return User.query.get(user_id)

def update_user(user_id, new_data):
    user = User.query.get(user_id)
    if user:
        for key, value in new_data.items():
            setattr(user, key, value)
        db.session.commit()
        return True
    return False

def delete_user(user_id):
    user = User.query.get(user_id)
    if user:
        db.session.delete(user)
        db.session.commit()
        return True
    return False