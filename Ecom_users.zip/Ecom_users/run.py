# run.py
from flask import Flask
from user_service import db
from user_service.routes import user_bp
from user_service.auth import jwt

app = Flask(__name__)
app.config.from_object('user_service.config.Config')
db.init_app(app)
app.register_blueprint(user_bp)

if __name__ == '__main__':
    app.run(debug=True)
